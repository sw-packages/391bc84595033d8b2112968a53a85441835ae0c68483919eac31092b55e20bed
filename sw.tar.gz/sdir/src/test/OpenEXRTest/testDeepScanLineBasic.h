//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Contributors to the OpenEXR Project.
//

#ifndef TESTDEEPSCANLINEBASIC_H_
#define TESTDEEPSCANLINEBASIC_H_

#include <string>

void testDeepScanLineBasic (const std::string &tempDir);

#endif /* TESTDEEPSCANLINEBASIC_H_ */
