//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) DreamWorks Animation LLC and Contributors of the OpenEXR Project
//

#ifndef TESTRLE_H_
#define TESTRLE_H_

#include <string>
void testRle(const std::string&);

#endif /* TESTRLE_H_ */
